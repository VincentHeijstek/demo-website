// Laad de bedrijfsinformatie uit JSON
fetch("../data/companyInfo.json")
    .then(response => response.json())
    .then(data => {
        // Vul de placeholders in de HTML
        document.querySelectorAll("[data-placeholder]").forEach(el => {
            const key = el.getAttribute("data-placeholder");
            if (data[key]) {
                if (el.tagName === "A") {
                    el.textContent = data[key];
                    el.href = `mailto:${data[key]}`;
                } else {
                    el.textContent = data[key];
                }
            }
        });
    })
    .catch(error => console.error("Error loading company info JSON:", error));
