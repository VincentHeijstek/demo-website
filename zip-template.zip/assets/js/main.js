// Laad layout JSON
fetch("../data/layout.json")
    .then(response => response.json())
    .then(layout => {
        // Pas layout-instellingen toe
        if (layout.headerColor) {
            document.querySelector(".header").style.backgroundColor = layout.headerColor;
        }
        if (layout.headerTextColor) {
            document.querySelector(".header").style.color = layout.headerTextColor;
        }
        if (layout.buttonColor) {
            document.querySelectorAll(".btn").forEach(button => {
                button.style.backgroundColor = layout.buttonColor;
            });
        }
        if (layout.buttonHoverColor) {
            document.querySelectorAll(".btn").forEach(button => {
                button.addEventListener("mouseover", () => {
                    button.style.backgroundColor = layout.buttonHoverColor;
                });
                button.addEventListener("mouseout", () => {
                    button.style.backgroundColor = layout.buttonColor;
                });
            });
        }
        if (layout.backgroundColor) {
            document.body.style.backgroundColor = layout.backgroundColor;
        }
        if (layout.fontFamily) {
            document.body.style.fontFamily = layout.fontFamily;
        }
    })
    .catch(error => console.error("Error loading layout JSON:", error));

// Laad content JSON
fetch("../data/template1.json")
    .then(response => response.json())
    .then(data => {
        // Vul dynamische content
        document.querySelectorAll("[data-placeholder]").forEach(el => {
            const key = el.getAttribute("data-placeholder");
            if (data[key]) {
                if (el.tagName === "IMG") {
                    el.src = data[key];
                } else if (el.tagName === "A") {
                    // Controleer of het element een tekst-placeholder heeft
                    if (el.getAttribute("data-placeholder-text")) {
                        el.innerText = data[el.getAttribute("data-placeholder-text")];
                    }
                    el.href = data[key]; // Pas de href aan
                } else {
                    el.innerHTML = data[key];
                }
            }
        });
    })
    .catch(error => console.error("Error loading content JSON:", error));

// Laad footer JSON
fetch("../data/footer.json")
    .then(response => response.json())
    .then(footerData => {
        // Vul contactgegevens
        document.querySelector("[data-placeholder='phone']").textContent = footerData.contact.phone;
        document.querySelector("[data-placeholder='email']").textContent = footerData.contact.email;
        document.querySelector("[data-placeholder='email']").href = `mailto:${footerData.contact.email}`;
        document.querySelector("[data-placeholder='address']").textContent = footerData.contact.address;

        // Vul copyright
        document.querySelector("[data-placeholder='copyright']").textContent = footerData.copyright;

        // Vul sociale media links
        const socialMediaContainer = document.getElementById("socialMediaLinks");
        const socialMedia = footerData.socialMedia;

        // Icon mapping
        const icons = {
            facebook: "../assets/icons/facebook.svg",
            twitter: "../assets/icons/twitter.svg",
            linkedin: "../assets/icons/linkedin.svg"
        };

        // Voeg sociale media-links toe als ze bestaan
        Object.keys(socialMedia).forEach(key => {
            if (socialMedia[key]) {
                const listItem = document.createElement("li");
                const link = document.createElement("a");
                const img = document.createElement("img");

                link.href = socialMedia[key];
                link.target = "_blank";

                img.src = icons[key];
                img.alt = key;
                img.className = "social-icon";

                link.appendChild(img);
                listItem.appendChild(link);
                socialMediaContainer.appendChild(listItem);
            }
        });
    })
    .catch(error => console.error("Error loading footer JSON:", error));
