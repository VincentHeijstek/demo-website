<?php
require '../db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['name'], $data['email'], $data['commentText'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Niet alle velden zijn ingevuld.']);
    exit;
}

try {
    $query = $pdo->prepare("INSERT INTO comments (name, email, opt_out, comment_text) VALUES (:name, :email, :opt_out, :comment_text)");
    $query->execute([
        ':name' => $data['name'],
        ':email' => $data['email'],
        ':opt_out' => isset($data['optOut']) ? (int) $data['optOut'] : 0,
        ':comment_text' => $data['commentText'],
    ]);

    echo json_encode(['success' => true, 'name' => $data['name'], 'commentText' => $data['commentText']]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Databasefout: ' . $e->getMessage()]);
}
?>
